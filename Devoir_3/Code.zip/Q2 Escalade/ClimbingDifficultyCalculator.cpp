// Nom, Matricule
// Nom, Matricule

#include "ClimbingDifficultyCalculator.h"
#include <fstream>
#include <vector>
// #include <unordered_set>
// #include <math.h>
// #include <algorithm>
#include <iostream>

// ce fichier contient les definitions des methodes de la classe ClimbingDifficultyCalculator
// this file contains the definitions of the methods of the ClimbingDifficultyCalculator class

ClimbingDifficultyCalculator::ClimbingDifficultyCalculator()
{
}

int ClimbingDifficultyCalculator::CalculateClimbingDifficulty(std::string filename)
{
    // TODO
    // À compléter / To be completed
    // reading the file

    return 0;
}

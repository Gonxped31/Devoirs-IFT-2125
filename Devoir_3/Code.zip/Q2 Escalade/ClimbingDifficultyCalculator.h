// Nom, Matricule
// Nom, Matricule

//#include <vector>
#include <string>

// ce fichier contient les declarations des methodes de la classe ClimbingDifficultyCalculator
// peut être modifié si vous voulez ajouter d'autres méthodes à la classe
// this file contains the declarations of the methods of the ClimbingDifficultyCalculator class
// can be modified if you wish to add other methods to the class

class ClimbingDifficultyCalculator{
    public :
        ClimbingDifficultyCalculator();
        int CalculateClimbingDifficulty(std::string);
};